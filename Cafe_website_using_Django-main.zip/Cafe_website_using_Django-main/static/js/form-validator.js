function validator(){
    alert("validating..")
    return false;
}